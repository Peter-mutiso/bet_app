"use client";

import {
    IChartApi,
    LineStyle,
} from "lightweight-charts";

import { ChartSeries } from "../types";

/* ============================================================================
   BUILD SERIES
============================================================================ */

export function buildSeries(
    chart: IChartApi
): ChartSeries {

    console.log(
        "[createSeries] buildSeries called",
        chart
    );

    /* ------------------------------------------------------------------------
       Candlesticks
    ------------------------------------------------------------------------ */

    const candles = chart.addCandlestickSeries({

        upColor: "#22c55e",

        downColor: "#ef4444",

        borderVisible: false,

        wickUpColor: "#22c55e",

        wickDownColor: "#ef4444",

        priceLineVisible: true,

        lastValueVisible: true,

    });

    /* ------------------------------------------------------------------------
       Line
    ------------------------------------------------------------------------ */

    const line = chart.addLineSeries({

        color: "#3b82f6",

        lineWidth: 2,

        lineStyle: LineStyle.Solid,

        crosshairMarkerVisible: true,

        lastValueVisible: true,

        priceLineVisible: true,

    });

    /* ------------------------------------------------------------------------
       Area
    ------------------------------------------------------------------------ */

    const area = chart.addAreaSeries({

        lineColor: "#2563eb",

        topColor: "rgba(37,99,235,.35)",

        bottomColor: "rgba(37,99,235,.02)",

        lineWidth: 2,

        crosshairMarkerVisible: true,

        lastValueVisible: true,

        priceLineVisible: true,

    });

    /* ------------------------------------------------------------------------
       OHLC (Bar)
    ------------------------------------------------------------------------ */

    const ohlc = chart.addBarSeries({

        upColor: "#22c55e",

        downColor: "#ef4444",

        thinBars: false,

        openVisible: true,

    });

    /* ------------------------------------------------------------------------
       Only candles visible initially
    ------------------------------------------------------------------------ */

    candles.applyOptions({
        visible: true,
    });

    line.applyOptions({
        visible: false,
    });

    area.applyOptions({
        visible: false,
    });

    ohlc.applyOptions({
        visible: false,
    });

    const series: ChartSeries = {

        candles,

        line,

        area,

        ohlc,

    };

    console.log(
        "[createSeries] COMPLETE",
        series
    );

    return series;
}

/* ============================================================================
   SWITCH ACTIVE SERIES
============================================================================ */

export function setChartType(

    series: ChartSeries,

    type: string

) {

    series.candles.applyOptions({

        visible: type === "candles",

    });

    series.line.applyOptions({

        visible: type === "line",

    });

    series.area.applyOptions({

        visible: type === "area",

    });

    series.ohlc.applyOptions({

        visible: type === "ohlc",

    });

}

/* ============================================================================
   REMOVE SERIES
============================================================================ */

export function removeSeries(

    chart: IChartApi,

    series: ChartSeries

) {

    chart.removeSeries(series.candles);

    chart.removeSeries(series.line);

    chart.removeSeries(series.area);

    chart.removeSeries(series.ohlc);

}

/* ============================================================================
   UPDATE ACTIVE SERIES
============================================================================ */

export function updateSeries(

    series: ChartSeries,

    chartType: string,

    candle: any,

    price: number,

    time: any

) {

    switch (chartType) {

        case "line":

            series.line.update({

                time,

                value: price,

            });

            break;

        case "area":

            series.area.update({

                time,

                value: price,

            });

            break;

        case "ohlc":

            series.ohlc.update(candle);

            break;

        default:

            series.candles.update(candle);

    }

}