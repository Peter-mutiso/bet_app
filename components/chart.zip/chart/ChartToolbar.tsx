"use client";

import {
    CandlestickChart,
    LineChart,
    AreaChart,
    ChartColumn,
    Star,
    Maximize2,
    Activity,
    BarChart3,
    ChevronDown,
    Settings2,
} from "lucide-react";

import { useTradeStore } from "@/store/useTradeStore";

import TimeframeSelector from "./TimeframeSelector";
import IndicatorPanel from "./IndicatorPanel";

export default function ChartToolbar() {
    const market = useTradeStore((state) => state.selectedMarket);

    const chartType = useTradeStore((state) => state.chartType);

    const setChartType = useTradeStore((state) => state.setChartType);

    const toggleFullscreen = useTradeStore(
        (state) => state.toggleFullscreen
    );

    const addToWatchlist = useTradeStore(
        (state) => state.addToWatchlist
    );

    const setShowInstrumentPicker = useTradeStore(
        (state) => state.setShowInstrumentPicker
    );

    return (
        <header className="chart-toolbar">
            {/* ===================================================== */}
            {/* LEFT */}
            {/* ===================================================== */}

            <div className="toolbar-left">
                <div className="market-live">
                    <Activity size={13} />
                    <span>LIVE</span>
                </div>

                <button
                    type="button"
                    className="instrument-button"
                    onClick={() => setShowInstrumentPicker(true)}
                >
                    <div className="instrument-details">
                        <strong>
                            {market?.name ??
                                "Volatility 100 Index"}
                        </strong>

                        <small>
                            {market?.symbol ?? "R_100"}
                        </small>
                    </div>

                    <ChevronDown size={16} />
                </button>

                <TimeframeSelector />
            </div>

            {/* ===================================================== */}
            {/* CENTER */}
            {/* ===================================================== */}

            <div className="toolbar-center">
                <button
                    className={
                        chartType === "candles"
                            ? "tool-btn active"
                            : "tool-btn"
                    }
                    onClick={() => setChartType("candles")}
                    title="Candlestick"
                >
                    <CandlestickChart size={17} />
                </button>

                <button
                    className={
                        chartType === "ohlc"
                            ? "tool-btn active"
                            : "tool-btn"
                    }
                    onClick={() => setChartType("ohlc")}
                    title="OHLC"
                >
                    <ChartColumn size={17} />
                </button>

                <button
                    className={
                        chartType === "line"
                            ? "tool-btn active"
                            : "tool-btn"
                    }
                    onClick={() => setChartType("line")}
                    title="Line"
                >
                    <LineChart size={17} />
                </button>

                <button
                    className={
                        chartType === "area"
                            ? "tool-btn active"
                            : "tool-btn"
                    }
                    onClick={() => setChartType("area")}
                    title="Area"
                >
                    <AreaChart size={17} />
                </button>

                <div className="toolbar-divider" />
            </div>

            {/* ===================================================== */}
            {/* RIGHT */}
            {/* ===================================================== */}

            <div className="toolbar-right">
                <IndicatorPanel />

                <button
                    className="tool-btn"
                    title="Add to Watchlist"
                    onClick={() =>
                        addToWatchlist(
                            market?.name ??
                                "Volatility 100 Index"
                        )
                    }
                >
                    <Star size={16} />
                </button>

                <button
                    className="tool-btn"
                    title="Fullscreen"
                    onClick={toggleFullscreen}
                >
                    <Maximize2 size={16} />
                </button>

                <button
                    className="tool-btn"
                    title="Chart Settings"
                >
                    <Settings2 size={16} />
                </button>

                <button className="analysis-btn">
                    <BarChart3 size={16} />
                    <span>Analysis</span>
                </button>
            </div>
        </header>
    );
}