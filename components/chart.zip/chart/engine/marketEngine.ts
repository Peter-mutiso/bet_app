/*
===============================================================================
REALISTIC SYNTHETIC MARKET ENGINE
===============================================================================
*/

import { EngineState, TickResult } from "../types";

/*
===============================================================================
CREATE ENGINE
===============================================================================
*/

export function createEngine(initialPrice: number): EngineState {

    return {

        trend: 0,

        trendStrength: 0,

        momentum: 0,

        volatility: 1,

        impulse: 0,

        meanPrice: initialPrice,

        regime: 0,

        regimeLife: random(300, 1200),

        tickCounter: 0,

    };

}

/*
===============================================================================
VOLATILITY
===============================================================================
*/

export function applyVolatility(

    engine: EngineState,

    state: number

) {

    switch (state) {

        case 0:
            engine.volatility = 0.15;
            break;

        case 1:
            engine.volatility = 0.45;
            break;

        case 2:
            engine.volatility = 1;
            break;

        case 3:
            engine.volatility = 2;
            break;

        case 4:
            engine.volatility = 3.5;
            break;

        default:
            engine.volatility = 1;

    }

}

/*
===============================================================================
NEXT TICK
===============================================================================
*/

export function nextTick(

    engine: EngineState,

    currentPrice: number

): TickResult {

    engine.tickCounter++;

    /*
    ---------------------------------------------------------
    CHANGE MARKET REGIME
    ---------------------------------------------------------
    */

    engine.regimeLife--;

    if (engine.regimeLife <= 0) {

        engine.regime = randomInt(0, 2);

        engine.regimeLife = random(400, 1400);

        engine.trendStrength = random(-1, 1);

    }

    /*
    ---------------------------------------------------------
    TREND
    ---------------------------------------------------------
    */

    if (engine.regime === 1) {

        engine.trend += engine.trendStrength * 0.001;

    }

    else if (engine.regime === 2) {

        engine.trend -= engine.trend * 0.03;

    }

    /*
    ---------------------------------------------------------
    MOMENTUM
    ---------------------------------------------------------
    */

    engine.momentum *= 0.94;

    engine.momentum += gaussian() * 0.04;

    /*
    ---------------------------------------------------------
    RANDOM IMPULSE
    ---------------------------------------------------------
    */

    if (Math.random() < 0.003) {

        engine.impulse = gaussian() * 6;

    }

    engine.impulse *= 0.92;

    /*
    ---------------------------------------------------------
    MEAN REVERSION
    ---------------------------------------------------------
    */

    engine.meanPrice +=

        (currentPrice - engine.meanPrice)

        * 0.002;

    const meanForce =

        (engine.meanPrice - currentPrice)

        * 0.02;

    /*
    ---------------------------------------------------------
    NOISE
    ---------------------------------------------------------
    */

    const noise =

        gaussian()

        * engine.volatility

        * 0.35;

    /*
    ---------------------------------------------------------
    TOTAL MOVE
    ---------------------------------------------------------
    */

    let move =

        noise +

        engine.trend +

        engine.momentum +

        engine.impulse +

        meanForce;

    /*
    ---------------------------------------------------------
    RANDOM NEWS EVENT
    ---------------------------------------------------------
    */

    if (Math.random() < 0.0015) {

        move += gaussian() * 8;

    }

    /*
    ---------------------------------------------------------
    LIMIT EXTREME MOVES
    ---------------------------------------------------------
    */

    const maxMove =

        engine.volatility * 8;

    move =

        Math.max(

            -maxMove,

            Math.min(

                maxMove,

                move

            )

        );

    const nextPrice =

        Math.max(

            1,

            currentPrice + move

        );

    return {

        price: Number(

            nextPrice.toFixed(2)

        ),

        move,

    };

}

/*
===============================================================================
UTILITIES
===============================================================================
*/

function gaussian() {

    let u = 0;

    let v = 0;

    while (u === 0) u = Math.random();

    while (v === 0) v = Math.random();

    return (

        Math.sqrt(

            -2 *

            Math.log(u)

        )

        *

        Math.cos(

            2 *

            Math.PI *

            v

        )

    );

}

function random(min: number, max: number) {

    return min + Math.random() * (max - min);

}

function randomInt(min: number, max: number) {

    return Math.floor(random(min, max + 1));

}