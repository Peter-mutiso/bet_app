import {

    UTCTimestamp

} from "lightweight-charts";

import { Candle } from "../types";

/* ==========================================================
   CREATE NEW CANDLE
========================================================== */

export function createCandle(

    time: UTCTimestamp,

    open: number

): Candle {

    return {

        time,

        open,

        high: open,

        low: open,

        close: open,

    };

}

/* ==========================================================
   UPDATE CANDLE
========================================================== */

export function updateCandle(

    candle: Candle,

    marketPrice: number,

    move: number,

    volatility: number

) {

    candle.close +=

        (marketPrice - candle.close)

        * .35;

    const wick =

        Math.abs(move)

        *

        (.2 + Math.random() * .8)

        +

        Math.random()

        *

        volatility

        *

        .2;

    candle.high =

        Math.max(

            candle.high,

            candle.open,

            candle.close

        )

        + wick;

    candle.low =

        Math.min(

            candle.low,

            candle.open,

            candle.close

        )

        - wick;

}

/* ==========================================================
   GET CURRENT CANDLE TIME
========================================================== */

export function candleTimestamp(

    duration: number

): UTCTimestamp {

    return (

        Math.floor(

            Date.now()

            /

            1000

            /

            duration

        )

        *

        duration

    ) as UTCTimestamp;

}

/* ==========================================================
   PUSH HISTORY
========================================================== */

export function appendHistory(

    candles: Candle[],

    candle: Candle,

    max = 600

) {

    candles.push(candle);

    while (

        candles.length > max

    ) {

        candles.shift();

    }

}