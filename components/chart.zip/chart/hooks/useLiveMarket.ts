"use client";

import {
    useEffect,
    useRef,
} from "react";

import {
    ChartSeries,
    Candle,
} from "../types";

import {
    createEngine,
    applyVolatility,
    nextTick,
} from "../engine/marketEngine";

import {
    candleTimestamp,
    createCandle,
    updateCandle,
    appendHistory,
} from "../engine/candleEngine";

import {
    updateSeries,
} from "../chart/createSeries";

interface Props {

    chart: any;

    series: ChartSeries | null;

    chartType: string;

    volatilityState: number;

    candleDuration: number;

    livePriceRef: React.MutableRefObject<number>;

    candlesRef: React.MutableRefObject<Candle[]>;

    activeCandleRef: React.MutableRefObject<Candle | null>;

    lastTimeRef: React.MutableRefObject<number>;

    followLiveRef: React.MutableRefObject<boolean>;

    setPrice(price: number): void;

}

const TICKS_PER_SECOND = 12;

const TICK_INTERVAL = 1000 / TICKS_PER_SECOND;

export function useLiveMarket({

    chart,

    series,

    chartType,

    volatilityState,

    candleDuration,

    livePriceRef,

    candlesRef,

    activeCandleRef,

    lastTimeRef,

    followLiveRef,

    setPrice,

}: Props) {

    const intervalRef = useRef<NodeJS.Timeout | null>(null);

    const engineRef = useRef(

        createEngine(

            livePriceRef.current

        )

    );

    useEffect(() => {

        if (!chart || !series) {

            console.log("[useLiveMarket] Waiting...");

            return;

        }

        console.log("[useLiveMarket] Started");

        intervalRef.current = setInterval(() => {

            applyVolatility(

                engineRef.current,

                volatilityState

            );

            const tick = nextTick(

                engineRef.current,

                livePriceRef.current

            );

            livePriceRef.current = tick.price;

            setPrice(tick.price);

            const now = candleTimestamp(

                candleDuration

            );

            /*
            ====================================================
            NEW CANDLE
            ====================================================
            */

            if (

                now !== lastTimeRef.current ||

                !activeCandleRef.current

            ) {

                const candle = createCandle(

                    now,

                    tick.price

                );

                activeCandleRef.current = candle;

                lastTimeRef.current = now;

                appendHistory(

                    candlesRef.current,

                    candle

                );

            }

            /*
            ====================================================
            UPDATE CURRENT CANDLE
            ====================================================
            */

            updateCandle(

                activeCandleRef.current!,

                tick.price,

                tick.move,

                engineRef.current.volatility

            );

            /*
            ====================================================
            UPDATE CHART
            ====================================================
            */

            updateSeries(

                series,

                chartType,

                activeCandleRef.current,

                tick.price,

                now

            );

            /*
            ====================================================
            KEEP VIEW AT END
            ====================================================
            */

            if (

                followLiveRef.current

            ) {

                chart

                    .timeScale()

                    .scrollToRealTime();

            }

        }, TICK_INTERVAL);

        return () => {

            if (

                intervalRef.current

            ) {

                clearInterval(

                    intervalRef.current

                );

            }

        };

    }, [

        chart,

        series,

        chartType,

        volatilityState,

        candleDuration,

        setPrice,

        livePriceRef,

        candlesRef,

        activeCandleRef,

        lastTimeRef,

        followLiveRef,

    ]);

}